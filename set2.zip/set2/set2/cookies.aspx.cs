﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace set2
{
    public partial class cookies : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void SaveCookie(string username)
        {
            HttpCookie cookie = new HttpCookie("Username", username);
            cookie.Expires = DateTime.Now.AddDays(7);
            cookie.HttpOnly = true;
            Response.Cookies.Set(cookie);
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUser.Text))
            {
                lblMessage.Text = "Enter a username.";
                return;
            }

            SaveCookie(txtUser.Text.Trim());
            lblMessage.Text = "Cookie created successfully.";
        }

        protected void btnRetrieve_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["Username"];

            lblMessage.Text = cookie == null
                ? "Cookie not found."
                : "Stored username: " +
                  Server.HtmlEncode(cookie.Value);
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Username"] == null)
            {
                lblMessage.Text = "Create a cookie first.";
                return;
            }

            if (string.IsNullOrWhiteSpace(txtUser.Text))
            {
                lblMessage.Text = "Enter a new username.";
                return;
            }

            SaveCookie(txtUser.Text.Trim());
            lblMessage.Text = "Cookie updated successfully.";
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = new HttpCookie("Username", "");
            cookie.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Set(cookie);

            lblMessage.Text = "Cookie deletion requested.";
        }
    }
}