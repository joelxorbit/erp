﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="cookies.aspx.cs" Inherits="set2.cookies" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <h2>Cookie Manipulation</h2>

    User Name:
    <asp:TextBox ID="txtUser" runat="server" />
    <br /><br />

    <asp:Button ID="btnCreate" runat="server"
        Text="Create Cookie" OnClick="btnCreate_Click" />
    <asp:Button ID="btnRetrieve" runat="server"
        Text="Retrieve Cookie" OnClick="btnRetrieve_Click" />
    <asp:Button ID="btnUpdate" runat="server"
        Text="Update Cookie" OnClick="btnUpdate_Click" />
    <asp:Button ID="btnDelete" runat="server"
        Text="Delete Cookie" OnClick="btnDelete_Click" />
    <br /><br />

    <asp:Label ID="lblMessage" runat="server"
        ForeColor="Blue" />
    </div>
    </form>
</body>
</html>
