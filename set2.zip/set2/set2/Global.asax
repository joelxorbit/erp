﻿<%@ Application Codebehind="Global.asax.cs" Inherits="set2.Global" Language="C#" %>
