﻿<%@ Application Codebehind="Global.asax.cs" Inherits="set4.Global" Language="C#" %>
