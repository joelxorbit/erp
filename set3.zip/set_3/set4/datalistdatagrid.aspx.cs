﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
namespace set4
{
    public partial class datalistdatagrid : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dt = new DataTable();

                dt.Columns.Add("Name");
                dt.Columns.Add("Department");
                dt.Columns.Add("Mark");

                dt.Rows.Add("Arun", "Computer Science", "85");
                dt.Rows.Add("Priya", "Information Technology", "90");
                dt.Rows.Add("Kumar", "Computer Science", "78");

                DataList1.DataSource = dt;
                DataList1.DataBind();

                DataGrid1.DataSource = dt;
                DataGrid1.DataBind();
            }
        }

        protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}