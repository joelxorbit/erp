﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="datalistdatagrid.aspx.cs" Inherits="set4.datalistdatagrid" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">

    <h2>Student Details Using DataList</h2>

        <asp:DataList ID="DataList1" runat="server"
            RepeatColumns="2" CellPadding="10">
            <ItemTemplate>
                <div style="border:1px solid blue; padding:10px;">
                    <b>Name:</b> <%# Eval("Name") %><br />
                    <b>Department:</b> <%# Eval("Department") %><br />
                    <b>Mark:</b> <%# Eval("Mark") %>
                </div>
            </ItemTemplate>
        </asp:DataList>

        <h2>Student Details Using DataGrid</h2>

        <asp:DataGrid ID="DataGrid1" runat="server"
            AutoGenerateColumns="False"
            BorderWidth="1" CellPadding="5" 
            onselectedindexchanged="DataGrid1_SelectedIndexChanged">
            <HeaderStyle BackColor="LightBlue" Font-Bold="True" />
            <Columns>
                <asp:BoundColumn DataField="Name"
                    HeaderText="Student Name" />
                <asp:BoundColumn DataField="Department"
                    HeaderText="Department" />
                <asp:BoundColumn DataField="Mark"
                    HeaderText="Mark" />
            </Columns>
        </asp:DataGrid>
    
    </form>
</body>
</html>
