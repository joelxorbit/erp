﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="statemanagement.aspx.cs" Inherits="set4.statemanagement" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <h2>State Management Using Cookies and Session</h2>

        Enter Username:
        <asp:TextBox ID="txtName" runat="server"></asp:TextBox>
        <br /><br />

        <asp:Button ID="btnInsert" runat="server"
            Text="Insert" OnClick="btnInsert_Click" />
        <br /><br />

        <asp:Label ID="lblMessage" runat="server"></asp:Label>
    </div>
    </form>
</body>
</html>
