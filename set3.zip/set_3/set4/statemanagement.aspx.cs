﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace set4
{
    public partial class statemanagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnStore_Click(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            string username = txtName.Text.Trim();

            if (username == "")
            {
                lblMessage.Text = "Please enter username.";
                return;
            }

            // Insert username into Cookie
            HttpCookie cookie = new HttpCookie("Username", username);
            cookie.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(cookie);

            // Insert username into Session
            Session["Username"] = username;

            lblMessage.Text = "Username inserted successfully into Cookie and Session.";
        }
    }
}