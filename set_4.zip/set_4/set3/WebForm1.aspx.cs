﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace set3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login1_Authenticate(
            object sender, AuthenticateEventArgs e)
        {
            e.Authenticated =
                Login1.UserName == "admin" &&
                Login1.Password == "admin123";
        }
        protected void Login1_LoggedIn(object sender, EventArgs e)
        {
            Session["Username"] = Login1.UserName;
        }
    }
}