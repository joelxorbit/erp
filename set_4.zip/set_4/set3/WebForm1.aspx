﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="set3.WebForm1" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
     <h2>Login Form</h2>

    <asp:Login ID="Login1" runat="server"
        OnAuthenticate="Login1_Authenticate"
        OnLoggedIn="Login1_LoggedIn"
        DestinationPageUrl="Welcome.aspx"
        FailureText="Invalid username or password."
        TitleText="User Login" />

    <asp:Label ID="lblMessage" runat="server"
        ForeColor="Red" />
    </div>
    </form>
</body>
</html>
