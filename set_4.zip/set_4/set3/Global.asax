﻿<%@ Application Codebehind="Global.asax.cs" Inherits="set3.Global" Language="C#" %>
