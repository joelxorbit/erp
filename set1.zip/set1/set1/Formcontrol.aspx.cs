﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace set1
{
    public partial class Formcontrol : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string gender = rbMale.Checked ? "Male" :
                            rbFemale.Checked ? "Female" : "Not selected";

            string hobbies = "";

            if (chkReading.Checked) hobbies += "Reading, ";
            if (chkSports.Checked) hobbies += "Sports, ";
            if (chkMusic.Checked) hobbies += "Music, ";

            if (hobbies == "")
                hobbies = "None";
            else
                hobbies = hobbies.TrimEnd(' ', ',');

            lblResult.Text =
                "Student Details:<br/>" +
                "Name: " + Server.HtmlEncode(txtName.Text) + "<br/>" +
                "Register Number: " + Server.HtmlEncode(txtRegNo.Text) + "<br/>" +
                "Email: " + Server.HtmlEncode(txtEmail.Text) + "<br/>" +
                "Gender: " + gender + "<br/>" +
                "Department: " + Server.HtmlEncode(ddlDepartment.SelectedValue) + "<br/>" +
                "Hobbies: " + Server.HtmlEncode(hobbies);
        }
    }
}