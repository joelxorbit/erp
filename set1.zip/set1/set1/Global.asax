﻿<%@ Application Codebehind="Global.asax.cs" Inherits="set1.Global" Language="C#" %>
