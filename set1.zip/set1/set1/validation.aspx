﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="validation.aspx.cs" Inherits="set1.validation" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <h2>User Registration Form</h2>

    Name:
    <asp:TextBox ID="txtName" runat="server" />
    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server"
        ControlToValidate="txtName" ErrorMessage="Name required"
        ForeColor="Red" />
    <br /><br />

    Email:
    <asp:TextBox ID="txtEmail" runat="server" />
    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server"
        ControlToValidate="txtEmail" ErrorMessage="Email required"
        ForeColor="Red" />
    <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server"
        ControlToValidate="txtEmail"
        ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]+$"
        ErrorMessage="Invalid email" ForeColor="Red" />
    <br /><br />

    Password:
    <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" />
    <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server"
        ControlToValidate="txtPassword" ErrorMessage="Password required"
        ForeColor="Red" />
    <br /><br />

    Confirm Password:
    <asp:TextBox ID="txtConfirm" runat="server" TextMode="Password" />
    <asp:CompareValidator ID="CompareValidator1" runat="server"
        ControlToValidate="txtConfirm"
        ControlToCompare="txtPassword"
        ErrorMessage="Passwords do not match" ForeColor="Red" />
    <br /><br />

    Age:
    <asp:TextBox ID="txtAge" runat="server" />
    <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server"
        ControlToValidate="txtAge" ErrorMessage="Age required"
        ForeColor="Red" />
    <asp:RangeValidator ID="RangeValidator1" runat="server"
        ControlToValidate="txtAge" MinimumValue="18"
        MaximumValue="60" Type="Integer"
        ErrorMessage="Age must be 18 to 60" ForeColor="Red" />
    <br /><br />

    <asp:Button ID="btnRegister" runat="server"
        Text="Register" OnClick="btnRegister_Click" />
    <br /><br />

    <asp:ValidationSummary ID="vs1" runat="server"
        ForeColor="Red" />
    <asp:Label ID="lblMessage" runat="server" />
    </div>
    </form>
</body>
</html>
