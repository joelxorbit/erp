﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Formcontrol.aspx.cs" Inherits="set1.Formcontrol" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <h2>Student Registration Form</h2>

    Name:
    <asp:TextBox ID="txtName" runat="server" />
    <br /><br />

    Register Number:
    <asp:TextBox ID="txtRegNo" runat="server" />
    <br /><br />

    Email:
    <asp:TextBox ID="txtEmail" runat="server" />
    <br /><br />

    Gender:
    <asp:RadioButton ID="rbMale" runat="server"
        GroupName="Gender" Text="Male" />
    <asp:RadioButton ID="rbFemale" runat="server"
        GroupName="Gender" Text="Female" />
    <br /><br />

    Department:
    <asp:DropDownList ID="ddlDepartment" runat="server">
        <asp:ListItem>Computer Science</asp:ListItem>
        <asp:ListItem>Information Technology</asp:ListItem>
        <asp:ListItem>Commerce</asp:ListItem>
        <asp:ListItem>Mathematics</asp:ListItem>
    </asp:DropDownList>
    <br /><br />

    Hobbies:
    <asp:CheckBox ID="chkReading" runat="server" Text="Reading" />
    <asp:CheckBox ID="chkSports" runat="server" Text="Sports" />
    <asp:CheckBox ID="chkMusic" runat="server" Text="Music" />
    <br /><br />

    <asp:Button ID="btnSubmit" runat="server"
        Text="Submit" OnClick="btnSubmit_Click" />
    <br /><br />

    <asp:Label ID="lblResult" runat="server"
        ForeColor="Blue" />
    </div>
    </form>
</body>
</html>
